import face_recognition
import app_tier_configuration as config
import boto3
import os
import time

aws = boto3.session.Session(aws_access_key_id=config.AWS_ACCESS_KEY,
                            aws_secret_access_key=config.AWS_SECRET_KEY,
                            region_name=config.AWS_REGION)

sqs = aws.client(service_name='sqs')
s3 = aws.client(service_name='s3')
curr_path = os.getcwd() + "/"


def inQueueMessages():
    response = sqs.get_queue_attributes(
        QueueUrl=config.AWS_REQUEST_QUEUE,
        AttributeNames=['All']
    )
    messages = response['Attributes']['ApproximateNumberOfMessages']

    return int(messages)


def main():
    while inQueueMessages() > 0:
        # sending image to the Request Queue
        try:
            message_received = sqs.receive_message(
                QueueUrl=config.AWS_REQUEST_QUEUE,
                MaxNumberOfMessages=1,
                MessageAttributeNames=['All'],
                WaitTimeSeconds=5,
                VisibilityTimeout=10
            )
            message = message_received['Messages'][0]

            image_location = message['Body']
            receipt = message['ReceiptHandle']
            file_id = message['MessageAttributes']['FileId']['StringValue']

            s3.download_file(config.AWS_INPUT_BUCKET, image_location, Filename=image_location)
            classification_result = face_recognition.face_match(image_location)
            os.remove(image_location)

            output = image_location + ":" + classification_result
            filename = image_location.split(".")[0] + ".txt"

            file = open(filename, "x")
            file.write(output)
            file.close()

            s3.upload_file(filename, config.AWS_OUTPUT_BUCKET, filename)
            os.remove(filename)

            # Uploading received output to the Response Queue
            sqs.send_message(
                QueueUrl=config.AWS_RESPONSE_QUEUE,
                DelaySeconds=0,
                MessageAttributes={
                    'FileId': {
                        'DataType': 'String',
                        'StringValue': file_id
                    }
                },
                MessageBody=output
            )

            # Queue Message Deleting
            sqs.delete_message(
                QueueUrl=config.AWS_REQUEST_QUEUE,
                ReceiptHandle=receipt
            )
        except Exception as e:
            print(e)


while True:
    while inQueueMessages() == 0:
        time.sleep(5)
    main()
