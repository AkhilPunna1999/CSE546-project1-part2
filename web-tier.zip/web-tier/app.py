from flask import Flask, request
import web_tier as config


app = Flask(__name__)


@app.route("/", methods=['POST'])
def predictImage():
    output = config.Handler(request)

    if output != "Error":
        return output, 200
    else:
        return 500


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8000, debug=True)
