import web_tier_configuration as lib
import boto3
import os
import uuid

aws = boto3.session.Session(aws_access_key_id=lib.AWS_ACCESS_KEY,
                            aws_secret_access_key=lib.AWS_SECRET_KEY,
                            region_name=lib.AWS_REGION)

sqs = aws.client(service_name='sqs')
s3 = aws.client(service_name='s3')
currentpath = os.getcwd() + "/"


def Handler(request):
    try:
        file = request.files['inputFile']
        NameOfFile = file.filename
        FileIdentifier = NameOfFile[5:8]
        file.save(currentpath + NameOfFile)

        s3.upload_file(currentpath + NameOfFile, lib.AWS_INPUT_BUCKET, NameOfFile)
        os.remove(currentpath + NameOfFile)

        # Send message to the Queue
        sqs.send_message(
            QueueUrl=lib.AWS_REQUEST_QUEUE,
            MessageBody=NameOfFile,
            DelaySeconds=0,
            MessageAttributes={
                'FileId': {
                    'DataType': 'String',
                    'StringValue': str(FileIdentifier)
                }
            }
        )

        # Receiving the Response from the Queue
        message_available = False
        message = None
        delivery = None
        while not message_available:
            responses: list = sqs.receive_message(
                QueueUrl=lib.AWS_RESPONSE_QUEUE,
                AttributeNames=[
                    'SenderId'
                ],
                MaxNumberOfMessages=10,
                MessageAttributeNames=[
                    'All'
                ],
                WaitTimeSeconds=5
            ).get('Messages', [])

            for response in responses:
                delivery = response['ReceiptHandle']
                received_id = response['MessageAttributes']['FileId']['StringValue']
                if received_id == FileIdentifier:
                    message_available = True
                    message = response['Body']
                    break

        # Deleteing the msg from Response Queue 
        sqs.delete_message(
            QueueUrl=lib.AWS_RESPONSE_QUEUE,
            ReceiptHandle=delivery
        )

        return message

    except Exception as e:
        return "Error"
