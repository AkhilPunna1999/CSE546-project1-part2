import boto3
import time


aws_access_key_id = "AKIA6GBMDEWNJC26JBU3"
aws_secret_access_key = "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"
print(aws_access_key_id)
print(aws_secret_access_key)

AWS_REGION = "us-east-1"
REQUEST_QUEUE_URL = (
   "https://sqs.us-east-1.amazonaws.com/975050057114/1225901900-req-queue"
)
RESPONSE_QUEUE_URL = (
    "https://sqs.us-east-1.amazonaws.com/975050057114/1225901900-resp-queue"
)
LAUNCH_TEMPLATE_ID = "lt-0245ee0246125992d"
MAXNOOFINSTANCES = 20
SCALE_UP_LIMIT = 1
SCALE_DOWN_LIMIT = 5
RESTTIME = 1

ec2 = boto3.resource(
    "ec2",
    region_name=AWS_REGION,
    aws_access_key_id=aws_access_key_id,
    aws_secret_access_key=aws_secret_access_key,
)
sqs = boto3.client(
    "sqs",
    region_name=AWS_REGION,
    aws_access_key_id=aws_access_key_id,
    aws_secret_access_key=aws_secret_access_key,
)


def get_instance_count():
    instances = ec2.instances.filter(
        Filters=[
            {
                "Name": "instance-state-name",
                "Values": ["running", "pending", "stopped"],
            },
            {"Name": "tag:Name", "Values": ["app-tier-instance-*"]},
        ]
    )
    return sum(1 for _ in instances)


def get_message_count():
    response = sqs.get_queue_attributes(
        QueueUrl=REQUEST_QUEUE_URL, AttributeNames=["ApproximateNumberOfMessages"]
    )
    return int(response["Attributes"]["ApproximateNumberOfMessages"])


def upScale(instances_to_add):
    instance_count = get_instance_count()
    if instance_count < MAXNOOFINSTANCES:
        nextNumberInstance = instance_count + 1
        for _ in range(instances_to_add):
            ec2.create_instances(
                MinCount=1,
                MaxCount=1,
                LaunchTemplate={"LaunchTemplateId": LAUNCH_TEMPLATE_ID},
                TagSpecifications=[
                    {
                        "ResourceType": "instance",
                        "Tags": [
                            {
                                "Key": "Name",
                                "Value": f"app-tier-instance-{nextNumberInstance}",
                            }
                        ],
                    }
                ],
                IamInstanceProfile={
                    "Arn": "arn:aws:iam::975050057114:instance-profile/autoscaling"
                },
            )
            print(
                f"Scaling up: new instance launched -{nextNumberInstance}."
            )
            nextNumberInstance += 1
    else:
        print("max number reached, Cannot add more instances")


def downScale(instances_to_terminate):
    instances = ec2.instances.filter(
        Filters=[
            {"Name": "instance-state-name", "Values": ["running"]},
            {"Name": "tag:Name", "Values": ["app-tier-instance-*"]},
        ]
    )

    validatedInstances = [
        instance
        for instance in instances
        if any(
            tag["Key"] == "Name" and tag["Value"].startswith("app-tier-instance-")
            for tag in instance.tags
        )
    ]

    validatedInstances.sort(
        key=lambda instance: int(
            [
                tag["Value"].split("-")[-1]
                for tag in instance.tags
                if tag["Key"] == "Name"
            ][0]
        ),
        reverse=True,
    )

    for instance in validatedInstances[:instances_to_terminate]:
        print(f"Scaling down: Terminating instance {instance.id}.")
        instance.terminate()


def autoscaling():

    while True:
        instance_count = get_instance_count()
        message_count = get_message_count()


        if message_count > SCALE_UP_LIMIT and instance_count < MAXNOOFINSTANCES:
            upScale(1)
        elif message_count <= SCALE_DOWN_LIMIT and instance_count > 0:
            downScale(min(instance_count, SCALE_DOWN_LIMIT))

        time.sleep(RESTTIME)


if __name__ == "__main__":
    autoscaling()
